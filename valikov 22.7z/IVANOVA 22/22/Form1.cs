﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void button1_Click(object sender, EventArgs e) //добавить фото
        {
            OpenFileDialog opfl = new OpenFileDialog();
            opfl.ShowDialog();
        }

        public void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        public void button2_Click(object sender, EventArgs e) //готово
        {

            Form2 newForm2 = new Form2();
            this.Hide();
            newForm2.Show();
            newForm2.label1.Text = this.textBox1.Text;//ф
            newForm2.label2.Text = this.textBox2.Text;//и
            newForm2.label3.Text = this.textBox3.Text;//о
            newForm2.label4.Text = this.dateTimePicker1.Text; //дата
            newForm2.label5.Text = this.comboBox1.Text; //пол
            newForm2.label7.Text = this.textBox4.Text; //примечание
           


        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void textBox1_TextChanged(object sender, EventArgs e) //фамилия
        {

        }

        public void textBox4_TextChanged(object sender, EventArgs e) //примечание 
        {

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e) //файл
        {

        }
    }
}
