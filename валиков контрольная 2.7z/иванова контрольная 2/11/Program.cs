﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            double n = Convert.ToInt32(Console.ReadLine());
            double sum = 0;
            for (double i = 1; i <= n; i ++)
            {
                sum += 1/i;
            }
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
