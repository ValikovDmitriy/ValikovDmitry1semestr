﻿using System;

class Program
{
    static void Main()
    {
        for (int a = 1; a <= 100; a++)
        {
            int y1 = CalculateY1(a);
            int y2 = CalculateY2(a);

            int gcdValue = GCD(y1, y2);

            if (gcdValue > 1)
            {
                Console.WriteLine($"a = {a}: НОД(y1, y2) = {gcdValue}");
            }
        }
    }

    static int CalculateY1(int a)
    {
        return a * a * (a * a + 12) - 5;
    }

    static int CalculateY2(int a)
    {
        return a * (a * a + 1);
    }

    static int GCD(int x, int y)
    {
        while (y != 0)
        {
            int temp = y;
            y = x % y;
            x = temp;
        }
        return Math.Abs(x);
    }
}

