﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите положительное целое число: ");
        int decimalNumber = int.Parse(Console.ReadLine());

        if (decimalNumber < 0)
        {
            Console.WriteLine("Ошибка: Введите положительное целое число.");
            return;
        }

        string binaryRepresentation = Convert.ToString(decimalNumber, 2);
        string octalRepresentation = Convert.ToString(decimalNumber, 8);
        string hexadecimalRepresentation = Convert.ToString(decimalNumber, 16).ToUpper();

        Console.WriteLine($"{decimalNumber}(10) = {binaryRepresentation}(2) = {octalRepresentation}(8) = {hexadecimalRepresentation}(16)");
    }
}

