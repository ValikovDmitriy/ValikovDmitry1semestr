﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите N: ");
        int N = Convert.ToInt32(Console.ReadLine());

        long sumUsingLoop = CalculateSumUsingLoop(N);
        Console.WriteLine($"Сумма ряда через цикл: {sumUsingLoop}");

        long sumUsingFormula = CalculateSumUsingFormula(N);
        Console.WriteLine($"Сумма ряда через формулу: {sumUsingFormula}");

        if (sumUsingLoop == sumUsingFormula)
        {
            Console.WriteLine("Результаты совпадают.");
        }
        else
        {
            Console.WriteLine("Результаты не совпадают.");
        }
    }

    static long CalculateSumUsingLoop(int N)
    {
        long sum = 0;

        for (int i = 0; i <= N; i++)
        {
            sum += (long)Math.Pow(2, i); 
        }

        return sum;
    }

    static long CalculateSumUsingFormula(int N)
    {
        long a = 1; 
        long r = 2; 

        return a * (long)(Math.Pow(r, N + 1) - 1) / (r - 1); 
    }
}

